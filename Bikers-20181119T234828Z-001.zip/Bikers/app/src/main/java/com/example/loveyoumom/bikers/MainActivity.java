package com.example.loveyoumom.bikers;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Scanner;



public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    // Define Variables
    Button button;
    EditText editText;
    Button b1;


    //onCreate Method for implement main_activity layout
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Get Variable's id , Button and Edittext
        button = findViewById(R.id.done);
        editText = findViewById(R.id.postalcode);

        //Create OnClick method for button DONE
        button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
              String PS = editText.getText().toString();

              //Validate PostalCode If the code length is 7 than it checks for proper sequence A1B 2C3 Canadian Code.
              if(PS.length()==7) {
                  boolean valid = true;

                  char a = PS.charAt(0); //first char define as a
                  char b = PS.charAt(2); //third char as b
                  char c = PS.charAt(4); //fifth char as c
                  char d = PS.charAt(1); //second char d
                  char e = PS.charAt(5); //sixth char as e
                  char f = PS.charAt(6); //last char as f
                  char g = PS.charAt(3); //forth char as g  so adbgcef
                  if (!Character.isLetter(a)) //if a is not char than valid=false(Invalid)
                      valid = false;
                  else if (!Character.isLetter(b))
                      valid = false;
                  else if (!Character.isDigit(c)) //if c is not degit (0-9) than Invalid
                      valid = false;
                  else if (!Character.isDigit(d))
                      valid = false;
                  else if (!Character.isLetter(e))
                      valid = false;
                  else if (!Character.isDigit(f))
                      valid = false;
                  else if (!Character.isWhitespace(g)) //Space
                      valid = false;

                  if (valid) { //if valid than go to mainmenu class where search button will appear
                      Intent intent = new Intent(MainActivity.this, MainMenu.class);
                      startActivity(intent);
                  }
                      //setContentView(R.layout.activity_main_menu);
                   else
                       //If is Invalid than display Toast
                        Toast.makeText(MainActivity.this,"Enter Valid Postal Code", Toast.LENGTH_LONG).show();

              }
           }

       });


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
                             drawer.addDrawerListener(toggle);toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                int id = menuItem.getItemId();
                switch (id) {
                    case R.id.profile:
                        Intent intent1 = new Intent(MainActivity.this, Profile.class);
                        startActivity(intent1);
                        //setContentView(R.layout.activity_profile);
                        break;
                    case R.id.payment:
                        Intent intent2 = new Intent(MainActivity.this, Payment.class);
                        startActivity(intent2);
                        //setContentView(R.layout.activity_payment);
                        break;
                    case R.id.credit:
                        Intent intent3 = new Intent(MainActivity.this, Credit.class);
                        startActivity(intent3);
                        //setContentView(R.layout.activity_credit);
                        break;
                    case R.id.tool:
                        Intent intent4 = new Intent(MainActivity.this, Tool.class);
                        startActivity(intent4);
                        //setContentView(R.layout.activity_tool);
                        break;
                }
                return false;
            }
        });

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

       /* if (id == R.id.profile) {
            // Handle the camera action
        } else if (id == R.id.payment) {

        } else if (id == R.id.credit) {

        } else if (id == R.id.tool) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }*/

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public class ValidatingPostcodes {
        public void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            //System.out.println("Please enter a Postcode:");
            String Pc1 = "[A-Z][0-9][A-Z][0-9][A-Z][0-9]";
            String Pc2 = "[A-Z][0-9][A-Z][ ][0-9][A-Z][0-9]";
            while (sc.hasNext())
            { if (sc.hasNext (Pc1))
                System.out.println ("Valid Postal Code");
            else if (sc.hasNext (Pc2))
                System.out.println ("Valid Postal Code");
            else System.out.println("Invalid Postal Code");
                sc.next();
            }
        }
    }
}
